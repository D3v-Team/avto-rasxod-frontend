import  { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  IconButton,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  FormControl,
  FormLabel,
  Input,
  VStack,
  SimpleGrid,
  Text,
  HStack,
  Center,
} from '@chakra-ui/react';
import { MoreVertical, Edit, Trash2, Fuel } from 'lucide-react';


import { apiFuel } from '../../Services/api/Fuels'; // API controller manzili

const focusStyle = {
  borderColor: "primary",
  boxShadow: "0 0 0 1px var(--chakra-colors-primary-500)",
  outline: "none",
};

const initialFormState = {
  unit: '',
  name: '',
  price: '',
};

const getIndicatorColor = (unit) => {
  if (!unit) return 'teal.400';
  const t = unit.toLowerCase();
  if (t.includes('benzin')) return 'orange.400';
  if (t.includes('metan') || t.includes('gaz')) return 'cyan.400';
  if (t.includes('propan')) return 'purple.400';
  return 'teal.400';
};

export default function FuelPage() {


  // State'lar
  const [fuels, setFuels] = useState([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState(initialFormState);
  const [selectedFuelId, setSelectedFuelId] = useState(null);
  const [modalMode, setModalMode] = useState('create');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Modal disclosure boshqaruvlari
  const { isOpen: isFormOpen, onOpen: onFormOpen, onClose: onFormClose } = useDisclosure();
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const [fuelToDelete, setFuelToDelete] = useState(null);

  // Backenddan barcha ma'lumotlarni yuklash funksiyasi
 const fetchFuels = async () => {
  try {
    setLoading(true);

    const res = await apiFuel.All(1, 100);

    setFuels(res.data.data ?? []);
  } catch (error) {
    console.error(error);
    setFuels([]);
  } finally {
    setLoading(false);
  }
};

  useEffect(() => {
    fetchFuels();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'price' ? (value === '' ? '' : Number(value)) : value,
    }));
  };

  const handleOpenCreate = () => {
    setModalMode('create');
    setFormData(initialFormState);
    onFormOpen();
  };

  const handleOpenEdit = (fuel) => {
    setModalMode('edit');
    setSelectedFuelId(fuel.id);
    setFormData({
      unit: fuel.type,
      name: fuel.name,
      price: fuel.price,
    });
    onFormOpen();
  };

  const handleOpenDelete = (fuel) => {
    setFuelToDelete(fuel);
    onDeleteOpen();
  };

  // Yaratish va Yangilash amali (Submit)
  const handleSubmit = async (e) => {
    e.preventDefault();
   if (!formData.unit.trim() || !formData.name.trim() || !formData.price) return;
    
    setIsSubmitting(true);
    try {
      if (modalMode === 'create') {
        await apiFuel.Create(formData);
      
      } else {
        await apiFuel.Update(selectedFuelId, formData);
      
      }
      onFormClose();
      fetchFuels();
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // O'chirish amali
  const handleConfirmDelete = async () => {
    if (!fuelToDelete?.id) return;
    try {
      setLoading(true);
      await apiFuel.Delete(fuelToDelete.id);

      onDeleteClose();
      fetchFuels();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box 
      pt={{ base: "12px", md: "20px" }} 
      pb={{ base: "12px", md: "20px" }} 
      pl={{ base: "12px", md: "25px" }}  
      pr={{ base: "12px", md: "24px" }}  
      w="100%"
    >
      {/* Header */}
      <Flex justify="space-between" align="center" mb="32px" gap={4}>
        <Heading size={{ base: "md", md: "lg" }} fontWeight="bold" letterSpacing="tight">
          Yoqilg'i turlari
        </Heading>
        <Button 
          bg="secondary" 
          color="white" 
          onClick={handleOpenCreate} 
          size={{ base: "sm", md: "md" }}
          _hover={{ opacity: 0.9 }}
          px={6}
          borderRadius="lg"
        >
          Yaratish
        </Button>
      </Flex>

      {/* Grid paneli */}
      {loading ? (
        <Center py={20}>
          loading
        </Center>
      ) : fuels.length === 0 ? (
        <Center py={20}>
          <Text color="textSub" fontSize="lg">Yoqilg'i turlari kiritilmagan</Text>
        </Center>
      ) : (
        <SimpleGrid columns={{ base: 1, sm: 2, md: 3 }} gap={6}>
          {fuels.map((fuel) => {
            const indicatorColor = getIndicatorColor(fuel.type);
            return (
              <Card 
                key={fuel.id} 
                bg="surfBlur" 
                border="1px solid" 
                borderColor="border" 
                borderRadius="2xl"
                position="relative"
                overflow="hidden"
                transition="all 0.25s ease"
                _hover={{
                  transform: "translateY(-4px)",
                  borderColor: indicatorColor,
                  boxShadow: "0 12px 20px -10px rgba(0,0,0,0.3)"
                }}
              >
                <Box 
                  position="absolute" 
                  left={0} 
                  top={0} 
                  bottom={0} 
                  w="5px" 
                  bg={indicatorColor}
                />

                <CardHeader pt={5} pb={1} pl={6} pr={4}>
                  <Flex justify="space-between" align="center">
                    <HStack spacing={2}>
                      <Fuel size={14} color={`var(--chakra-colors-${indicatorColor})`} />
                      <Text fontSize="xs" fontWeight="bold" textTransform="uppercase" color="textSub" tracking="widest">
                        {fuel.unit}
                      </Text>
                    </HStack>
                    
                    <Menu isLazy>
                      <MenuButton
                        as={IconButton}
                        aria-label="Amallar"
                        icon={<MoreVertical size={16} />}
                        variant="ghost"
                        size="sm"
                        borderRadius="full"
                        color="textSub"
                        _hover={{ bg: "whiteAlpha.200", color: "white" }}
                      />
                      <MenuList>
                        <MenuItem icon={<Edit size={14} />} onClick={() => handleOpenEdit(fuel)}>
                          Tahrirlash
                        </MenuItem>
                        <MenuItem icon={<Trash2 size={14} />} color="red.400" onClick={() => handleOpenDelete(fuel)}>
                          O'chirish
                        </MenuItem>
                      </MenuList>
                    </Menu>
                  </Flex>
                </CardHeader>
                
                <CardBody pl={6} pr={6} pb={5} pt={2}>
                  <VStack align="stretch" spacing={4}>
                    <Heading size="md" fontWeight="semibold" color="white">
                      {fuel.name}
                    </Heading>
                    
                    <Flex justify="space-between" align="baseline" pt={2} borderTop="1px solid" borderColor="whiteAlpha.100">
                      <Text fontSize="xs" color="textSub">Joriy narxi:</Text>
                      <Text fontSize="xl" fontWeight="extrabold" color="yellow.400">
                        {Number(fuel.price).toLocaleString('uz-UZ')} <Text as="span" fontSize="xs" fontWeight="normal" color="textSub">so'm</Text>
                      </Text>
                    </Flex>
                  </VStack>
                </CardBody>
              </Card>
            );
          })}
        </SimpleGrid>
      )}

      {/* Create / Edit Modal */}
      <Modal isOpen={isFormOpen} onClose={onFormClose} size={{ base: "full", sm: "md" }} isCentered>
        <ModalOverlay backdropFilter="blur(4px)" />
        <ModalContent borderRadius={{ base: "0px", sm: "xl" }} as="form" onSubmit={handleSubmit}>
          <ModalHeader bg="surfBlur" borderTopRadius={{ base: "0px", sm: "xl" }} fontSize="md" fontWeight="bold">
            {modalMode === 'create' ? "Yangi yoqilg'i kiritish" : "Yoqilg'ini tahrirlash"}
          </ModalHeader>
          <ModalCloseButton />
          
          <ModalBody bg="bg" py={5}>
            <VStack spacing={5}>
              <FormControl isRequired>
                <FormLabel fontSize="sm" color="textSub">Yoqilg'i turi</FormLabel>
               <FormControl isRequired>
    <FormLabel>Birligi</FormLabel>
    <Input
        bg="surfBlur"
        _focus={focusStyle}
        borderRadius="lg"
        name="unit"
        value={formData.unit}
        onChange={handleChange}
        placeholder="liter"
    />
</FormControl>
              </FormControl>

              <FormControl isRequired>
                <FormLabel fontSize="sm" color="textSub">Markasi / Nomi</FormLabel>
                <Input bg="surfBlur" _focus={focusStyle} borderRadius="lg" name="name" value={formData.name} onChange={handleChange} placeholder="Masalan: AI-95, Metan" />
              </FormControl>

              <FormControl isRequired>
                <FormLabel fontSize="sm" color="textSub">Narxi (so'mda)</FormLabel>
                <Input bg="surfBlur" _focus={focusStyle} borderRadius="lg" type="number" name="price" value={formData.price} onChange={handleChange} placeholder="9200" />
              </FormControl>
            </VStack>
          </ModalBody>

          <ModalFooter bg="surfBlur" borderBottomRadius={{ base: "0px", sm: "xl" }}>
            <Button border="1px solid" borderColor="whiteAlpha.300" variant="ghost" mr={3} onClick={onFormClose} size="sm" borderRadius="lg">
              Bekor qilish
            </Button>
            <Button bg="secondary" color="white" type="submit" isLoading={isSubmitting} size="sm" borderRadius="lg" px={5}>
              Saqlash
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={isDeleteOpen} onClose={onDeleteClose} isCentered size="sm">
        <ModalOverlay backdropFilter="blur(2px)" />
        <ModalContent borderRadius="xl">
          <ModalHeader bg="surfBlur" borderTopRadius="xl" fontSize="md" fontWeight="bold">O'chirishni tasdiqlash</ModalHeader>
          <ModalCloseButton />
          <ModalBody bg="bg" py={5}>
            <VStack align="start" spacing={2}>
              <Text fontSize="sm" color="text">
                Rostdan ham ushbu <Text as="span" fontWeight="bold">"{fuelToDelete?.name}"</Text> yoqilg'i ma'lumotini o'chirmoqchimisiz?
              </Text>
              <Text fontSize="xs" color="red.500" fontWeight="semibold">
                * Ushbu amalni ortga qaytarib bo'lmaydi!
              </Text>
            </VStack>
          </ModalBody>
          <ModalFooter bg="surfBlur" borderBottomRadius="xl">
            <Button 
              size="sm" 
              variant="ghost" 
              border="1px solid" 
              borderColor="red.500" 
              color="red.500" 
              mr={2} 
              onClick={onDeleteClose} 
              borderRadius="lg"
            >
              Yo'q
            </Button>
            <Button size="sm" bg="secondary" color="white" onClick={handleConfirmDelete} borderRadius="lg">Ha, o'chirish</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
}